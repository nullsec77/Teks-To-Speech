
import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { HistoryItem } from '../types';
import { decodeBase64, pcmToAudioBuffer, pcmToWavBlob } from '../utils/audioUtils';
import { DownloadIcon, PlayIcon, PauseIcon, AudioWaveIcon } from './icons';

interface AudioResultProps {
  item: HistoryItem;
}

export const AudioResult: React.FC<AudioResultProps> = ({ item }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  const prepareAudio = useCallback(async () => {
    setIsReady(false);
    if (!item.audioBase64) return;
    
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      const pcmData = decodeBase64(item.audioBase64);
      const buffer = await pcmToAudioBuffer(pcmData, audioContextRef.current);
      audioBufferRef.current = buffer;
      setIsReady(true);
    } catch (error) {
      console.error("Failed to decode or prepare audio:", error);
    }
  }, [item.audioBase64]);

  useEffect(() => {
    prepareAudio();
    
    return () => {
        // Cleanup on component unmount or when item changes
        if (sourceNodeRef.current) {
            sourceNodeRef.current.stop();
            sourceNodeRef.current.disconnect();
            sourceNodeRef.current = null;
        }
        setIsPlaying(false);
    }
  }, [item, prepareAudio]);

  const togglePlayPause = () => {
    if (!isReady || !audioContextRef.current || !audioBufferRef.current) return;

    if (isPlaying) {
      if (sourceNodeRef.current) {
        sourceNodeRef.current.stop();
      }
      setIsPlaying(false);
    } else {
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBufferRef.current;
      source.connect(audioContextRef.current.destination);
      source.onended = () => {
        setIsPlaying(false);
        sourceNodeRef.current = null;
      };
      source.start();
      sourceNodeRef.current = source;
      setIsPlaying(true);
    }
  };

  const handleDownload = () => {
    if (!item.audioBase64) return;
    const pcmData = decodeBase64(item.audioBase64);
    const blob = pcmToWavBlob(pcmData);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `incloud-tts-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="mt-8 bg-white dark:bg-gray-800/50 rounded-2xl shadow-lg backdrop-blur-sm border border-gray-200 dark:border-gray-700 p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-gray-700 dark:text-gray-300">
        <AudioWaveIcon className="w-6 h-6 text-indigo-500" />
        Audio yang Dihasilkan
      </h2>
      <div className="flex flex-col sm:flex-row items-center gap-4">
        <button
          onClick={togglePlayPause}
          disabled={!isReady}
          className="p-4 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-wait"
        >
          {isPlaying ? <PauseIcon className="w-8 h-8" /> : <PlayIcon className="w-8 h-8" />}
        </button>
        <div className="flex-grow w-full">
            <p className="text-sm text-gray-500 dark:text-gray-400 italic truncate">"{item.text}"</p>
        </div>
        <button
          onClick={handleDownload}
          disabled={!isReady}
          className="flex items-center gap-2 px-5 py-3 font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/50 rounded-xl hover:bg-indigo-200 dark:hover:bg-indigo-900/80 transition-colors duration-300 disabled:opacity-50"
        >
          <DownloadIcon className="w-5 h-5" />
          <span>Unduh .WAV</span>
        </button>
      </div>
    </div>
  );
};