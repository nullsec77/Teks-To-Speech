import React, { useState, useEffect } from 'react';
import { KeyIcon, SaveIcon, CheckCircleIcon } from './icons';

interface ApiKeyInputProps {
  apiKey: string;
  setApiKey: (key: string) => void;
}

export const ApiKeyInput: React.FC<ApiKeyInputProps> = ({ apiKey, setApiKey }) => {
  const [localKey, setLocalKey] = useState(apiKey);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setLocalKey(apiKey);
  }, [apiKey]);

  const handleSave = () => {
    setApiKey(localKey);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="bg-white dark:bg-gray-800/50 rounded-2xl shadow-lg backdrop-blur-sm border border-gray-200 dark:border-gray-700 p-6">
      <h2 className="text-xl font-semibold mb-3 flex items-center gap-2 text-gray-700 dark:text-gray-300">
        <KeyIcon className="w-6 h-6" />
        Kunci API Gemini
      </h2>
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          type="password"
          value={localKey}
          onChange={(e) => setLocalKey(e.target.value)}
          className="flex-grow p-3 bg-gray-100 dark:bg-gray-900/50 rounded-xl border-2 border-transparent focus:border-indigo-500 focus:ring-0 transition duration-300"
          placeholder="Masukkan kunci API Anda..."
        />
        <button
          onClick={handleSave}
          className="flex items-center justify-center gap-2 px-5 py-3 font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors duration-300 disabled:opacity-50"
          disabled={!localKey || localKey === apiKey}
        >
          {saved ? (
            <>
              <CheckCircleIcon className="w-5 h-5" />
              <span>Tersimpan</span>
            </>
          ) : (
            <>
              <SaveIcon className="w-5 h-5" />
              <span>Simpan Kunci</span>
            </>
          )}
        </button>
      </div>
       <p className="text-sm text-gray-500 dark:text-gray-400 mt-3">Kunci API Anda disimpan secara lokal di browser Anda dan tidak akan pernah dikirim ke server kami.</p>
    </div>
  );
};