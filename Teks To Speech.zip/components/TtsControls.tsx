import React from 'react';
import type { TtsOptions } from '../types';
import { CogIcon } from './icons';

interface TtsControlsProps {
  options: TtsOptions;
  setOptions: React.Dispatch<React.SetStateAction<TtsOptions>>;
}

const ControlSelect: React.FC<{
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  children: React.ReactNode;
}> = ({ label, value, onChange, children }) => (
  <div>
    <label className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">{label}</label>
    <select
      value={value}
      onChange={onChange}
      className="w-full p-3 bg-gray-100 dark:bg-gray-900/50 rounded-xl border-2 border-transparent focus:border-indigo-500 focus:ring-0 transition duration-300 appearance-none"
    >
      {children}
    </select>
  </div>
);

export const TtsControls: React.FC<TtsControlsProps> = ({ options, setOptions }) => {
  const handleChange = <K extends keyof TtsOptions>(key: K, value: TtsOptions[K]) => {
    setOptions(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="bg-white dark:bg-gray-800/50 rounded-2xl shadow-lg backdrop-blur-sm border border-gray-200 dark:border-gray-700 p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-gray-700 dark:text-gray-300">
        <CogIcon className="w-6 h-6" />
        Kustomisasi Suara
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <ControlSelect label="Jenis Kelamin" value={options.gender} onChange={(e) => handleChange('gender', e.target.value as TtsOptions['gender'])}>
          <option value="pria">Pria</option>
          <option value="wanita">Wanita</option>
        </ControlSelect>
        <ControlSelect label="Usia" value={options.age} onChange={(e) => handleChange('age', e.target.value as TtsOptions['age'])}>
          <option value="dewasa">Dewasa</option>
          <option value="muda">Muda</option>
          <option value="anak-anak">Anak-anak</option>
        </ControlSelect>
        <ControlSelect label="Aksen" value={options.accent} onChange={(e) => handleChange('accent', e.target.value as TtsOptions['accent'])}>
          <option value="Indonesia netral">Indonesia Netral</option>
          <option value="Jawa">Jawa</option>
          <option value="Sunda">Sunda</option>
          <option value="Melayu">Melayu</option>
        </ControlSelect>
        <ControlSelect label="Gaya Bicara" value={options.style} onChange={(e) => handleChange('style', e.target.value as TtsOptions['style'])}>
          <option value="ramah">Ramah</option>
          <option value="percaya diri">Percaya Diri</option>
          <option value="lembut">Lembut</option>
          <option value="energik">Energik</option>
        </ControlSelect>
        <ControlSelect label="Emosi" value={options.emotion} onChange={(e) => handleChange('emotion', e.target.value as TtsOptions['emotion'])}>
          <option value="natural">Natural</option>
          <option value="senang">Senang</option>
          <option value="sedih">Sedih</option>
          <option value="serius">Serius</option>
          <option value="santai">Santai</option>
          <option value="antusias">Antusias</option>
        </ControlSelect>
        <ControlSelect label="Tempo" value={options.tempo} onChange={(e) => handleChange('tempo', e.target.value as TtsOptions['tempo'])}>
          <option value="lambat">Lambat</option>
          <option value="normal">Normal</option>
          <option value="cepat">Cepat</option>
        </ControlSelect>
        <ControlSelect label="Nada" value={options.pitch} onChange={(e) => handleChange('pitch', e.target.value as TtsOptions['pitch'])}>
          <option value="rendah">Rendah</option>
          <option value="normal">Normal</option>
          <option value="tinggi">Tinggi</option>
        </ControlSelect>
        <ControlSelect label="Kepribadian" value={options.personality} onChange={(e) => handleChange('personality', e.target.value as TtsOptions['personality'])}>
          <option value="hangat">Hangat</option>
          <option value="humoris">Humoris</option>
          <option value="bijak">Bijak</option>
          <option value="pintar">Pintar</option>
        </ControlSelect>
        <ControlSelect label="Konteks" value={options.context} onChange={(e) => handleChange('context', e.target.value as TtsOptions['context'])}>
          <option value="storyteller">Story Telling</option>
          <option value="iklan">Iklan</option>
          <option value="customer service">Layanan Pelanggan</option>
          <option value="formal">Formal</option>
          <option value="story">Cerita</option>
        </ControlSelect>
      </div>
    </div>
  );
};