
import React from 'react';
import type { HistoryItem } from '../types';
import { HistoryIcon, PlayIcon, TrashIcon } from './icons';

interface HistoryListProps {
  history: HistoryItem[];
  onPlay: (item: HistoryItem) => void;
  onClear: () => void;
}

export const HistoryList: React.FC<HistoryListProps> = ({ history, onPlay, onClear }) => {
  return (
    <div className="bg-white dark:bg-gray-800/50 rounded-2xl shadow-lg backdrop-blur-sm border border-gray-200 dark:border-gray-700 p-6 h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold flex items-center gap-2 text-gray-700 dark:text-gray-300">
          <HistoryIcon className="w-6 h-6" />
          Riwayat
        </h2>
        {history.length > 0 && (
            <button onClick={onClear} className="text-sm text-red-500 hover:text-red-700 dark:hover:text-red-400 flex items-center gap-1 transition-colors">
                <TrashIcon className="w-4 h-4" />
                Bersihkan
            </button>
        )}
      </div>
      {history.length === 0 ? (
        <div className="flex items-center justify-center h-48 text-gray-500 dark:text-gray-400">
          <p>Audio yang Anda hasilkan akan muncul di sini.</p>
        </div>
      ) : (
        <ul className="space-y-3 max-h-[80vh] overflow-y-auto pr-2">
          {history.map(item => (
            <li key={item.id} className="p-3 bg-gray-100 dark:bg-gray-900/50 rounded-xl flex items-center justify-between gap-3">
              <div className="flex-grow overflow-hidden">
                <p className="font-medium truncate" title={item.text}>{item.text}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(item.timestamp).toLocaleString()}</p>
              </div>
              <button
                onClick={() => onPlay(item)}
                className="p-2 text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/50 rounded-full hover:bg-indigo-200 dark:hover:bg-indigo-900/80 transition-colors"
                title="Putar audio ini"
              >
                <PlayIcon className="w-5 h-5" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};