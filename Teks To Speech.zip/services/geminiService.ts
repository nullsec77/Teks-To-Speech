import { GoogleGenAI, Modality } from "@google/genai";

export async function generateSpeech(fullText: string, apiKey: string): Promise<string> {
  if (!apiKey) {
    throw new Error("Kunci API Gemini belum diatur. Silakan masukkan kunci API Anda.");
  }
  const ai = new GoogleGenAI({ apiKey });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: fullText }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
        },
      },
    });

    const audioPart = response.candidates?.[0]?.content?.parts?.[0];
    if (audioPart && audioPart.inlineData) {
      return audioPart.inlineData.data;
    } else {
      throw new Error("Tidak ada data audio yang diterima dari API Gemini.");
    }
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            throw new Error("Terjadi masalah otentikasi. Kunci API mungkin tidak valid.");
        }
    }
    throw new Error("Gagal menghasilkan suara. Silakan periksa koneksi jaringan Anda dan Kunci API.");
  }
}